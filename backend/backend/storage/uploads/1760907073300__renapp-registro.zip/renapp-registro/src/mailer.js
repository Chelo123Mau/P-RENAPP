import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
dotenv.config();

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});

export async function sendMail({ to, subject, html }) {
  const from = process.env.SMTP_FROM || 'RENAPP <no-reply@renapp.gob.bo>';
  try {
    await transporter.sendMail({ from, to, subject, html });
  } catch (e) {
    console.warn("No se pudo enviar correo:", e.message);
  }
}
