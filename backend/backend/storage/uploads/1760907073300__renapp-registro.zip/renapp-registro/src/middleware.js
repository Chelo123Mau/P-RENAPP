export function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/auth/login');
  next();
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session.user) return res.redirect('/auth/login');
    if (!roles.includes(req.session.user.role)) return res.status(403).send('Acceso denegado');
    next();
  };
}

export function attachUser(req, res, next) {
  res.locals.me = req.session.user || null;
  next();
}
