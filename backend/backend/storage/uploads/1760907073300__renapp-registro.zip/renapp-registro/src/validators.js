export function requiredFields(fields, body) {
  const missing = fields.filter(f => !String(body[f] ?? '').trim());
  return missing;
}
