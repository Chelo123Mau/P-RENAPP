import express from 'express';
import session from 'express-session';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import { attachUser, requireAuth, requireRole } from './middleware.js';
import { createUserWithStep1, finalizeUserCredentials, authenticate } from './auth.js';
import { requiredFields } from './validators.js';
import { sendMail } from './mailer.js';
import fs from 'fs';

dotenv.config();
const prisma = new PrismaClient();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'inseguro-cambiar',
  resave: false,
  saveUninitialized: false
}));
app.use(attachUser);

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + '-' + file.originalname.replace(/\s+/g, '_'));
  }
});
const upload = multer({ storage });

app.get('/', (req, res) => { res.render('home'); });

app.get('/auth/login', (req, res) => res.render('auth/login'));
app.post('/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await authenticate(username, password);
  if (!user) return res.render('auth/login', { error: 'Credenciales inválidas' });
  req.session.user = { id: user.id, username: user.username, role: user.role };
  res.redirect('/dashboard');
});

app.post('/auth/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

app.get('/auth/register', (req, res) => res.render('auth/register-step1'));
app.post('/auth/register/step1', upload.fields([
  { name: 'docRepresentation', maxCount: 1 },
  { name: 'docREJAP', maxCount: 1 }
]), async (req, res) => {
  const required = ['fullName','ciNumber','jobTitleEntity','address','email','departmentCity'];
  const missing = requiredFields(required, req.body);
  if (missing.length) return res.render('auth/register-step1', { error: `Faltan campos: ${missing.join(', ')}` });

  const docRepresentationPath = req.files['docRepresentation']?.[0]?.path || null;
  const docREJAPPath = req.files['docREJAP']?.[0]?.path || null;

  const user = await createUserWithStep1({
    ...req.body,
    docRepresentationPath,
    docREJAPPath
  });
  req.session.registerUserId = user.id;
  res.redirect('/auth/register/step2');
});

app.get('/auth/register/step2', (req, res) => {
  if (!req.session.registerUserId) return res.redirect('/auth/register');
  res.render('auth/register-step2');
});
app.post('/auth/register/step2', async (req, res) => {
  const { username, password, password2 } = req.body;
  if (!username || !password) return res.render('auth/register-step2', { error: 'Complete usuario y contraseña' });
  if (password !== password2) return res.render('auth/register-step2', { error: 'Las contraseñas no coinciden' });
  try {
    const user = await finalizeUserCredentials(req.session.registerUserId, username, password);
    await sendMail({
      to: user.email,
      subject: 'RENAPP: solicitud de registro enviada',
      html: `<p>Hola ${user.fullName},</p><p>Tu solicitud de registro fue enviada. Te notificaremos por correo cuando sea revisada.</p>`
    });
  } catch (e) {
    return res.render('auth/register-step2', { error: e.message });
  }
  delete req.session.registerUserId;
  res.render('auth/login', { success: 'Solicitud enviada. Te avisaremos por correo.' });
});

app.get('/dashboard', requireAuth, async (req, res) => {
  const me = await prisma.user.findUnique({ where: { id: req.session.user.id } });
  const entities = await prisma.entity.findMany({ where: { ownerId: me.id } });
  res.render('dashboard', { me, entities });
});

app.get('/review/inbox', requireRole('REVIEWER','ADMIN'), async (req, res) => {
  const users = await prisma.user.findMany({ where: { role: 'REQUESTER', status: { in: ['PENDING','NEEDS_INFO'] } } });
  const entities = await prisma.entity.findMany({ where: { status: { in: ['PENDING','NEEDS_INFO'] } }, include: { owner: true } });
  res.render('review/inbox', { users, entities });
});

app.get('/review/user/:id', requireRole('REVIEWER','ADMIN'), async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.params.id } });
  res.render('review/user-detail', { user });
});

app.post('/review/user/:id/action', requireRole('REVIEWER','ADMIN'), async (req, res) => {
  const { action, comments } = req.body;
  const status = action === 'APPROVE' ? 'APPROVED' : action === 'REJECT' ? 'REJECTED' : 'NEEDS_INFO';
  const user = await prisma.user.update({ where: { id: req.params.id }, data: { status, reviewerComments: comments } });
  await sendMail({
    to: user.email,
    subject: `RENAPP: resultado de tu registro` ,
    html: `<p>Estado: <b>${status}</b></p><p>${comments or ''}</p>`
  });
  res.redirect('/review/inbox');
});

app.get('/entity/create', requireRole('REQUESTER','ADMIN'), (req, res) => {
  res.render('entity/create');
});

app.post('/entity/create', requireRole('REQUESTER','ADMIN'), upload.single('docEntity'), async (req, res) => {
  const required = ['name','contactData','email','phone','entityType','incorporation','legalRep','tradeNumber','nit','isNational'];
  const missing = requiredFields(required, req.body);
  if (missing.length) return res.render('entity/create', { error: `Faltan campos: ${missing.join(', ')}` });

  const entity = await prisma.entity.create({
    data: {
      name: req.body.name,
      contactData: req.body.contactData,
      email: req.body.email,
      phone: req.body.phone,
      entityType: req.body.entityType,
      incorporation: req.body.incorporation,
      legalRep: req.body.legalRep,
      tradeNumber: req.body.tradeNumber,
      nit: req.body.nit,
      isNational: req.body.isNational == 'true',
      docPath: req.file?.path || null,
      ownerId: req.session.user.id
    }
  });

  await notifyReviewers(`Nueva solicitud de entidad: ${entity.name}`);

  res.render('dashboard', { success: 'Solicitud de registro de entidad enviada.', me: req.session.user, entities: await prisma.entity.findMany({ where: { ownerId: req.session.user.id } }) });
});

app.post('/review/entity/:id/action', requireRole('REVIEWER','ADMIN'), async (req, res) => {
  const { action, comments } = req.body;
  const status = action === 'APPROVE' ? 'APPROVED' : action === 'REJECT' ? 'REJECTED' : 'NEEDS_INFO';
  const entity = await prisma.entity.update({ where: { id: req.params.id }, data: { status, reviewerNotes: comments } , include: { owner: true }});
  await sendMail({
    to: entity.owner.email,
    subject: `RENAPP: resultado del registro de entidad` ,
    html: `<p>Entidad: <b>${entity.name}</b></p><p>Estado: <b>${status}</b></p><p>${comments or ''}</p>`
  });
  res.redirect('/review/inbox');
});

app.get('/project/create/:entityId', requireRole('REQUESTER','ADMIN'), async (req, res) => {
  const entity = await prisma.entity.findUnique({ where: { id: req.params.entityId } });
  if (!entity || (entity.ownerId !== req.session.user.id && req.session.user.role !== 'ADMIN')) return res.status(404).send('Entidad no encontrada');
  if (entity.status !== 'APPROVED') return res.status(403).send('La entidad debe estar aprobada para registrar proyectos.');
  res.render('project/create', { entity });
});

const projectUploads = upload.fields([
  { name: 'licEnvPath', maxCount: 1 },
  { name: 'ddmmPath', maxCount: 1 },
  { name: 'ovvValidation', maxCount: 1 },
  { name: 'minutesPath', maxCount: 1 },
  { name: 'reddGeojsonPath', maxCount: 1 },
  { name: 'reddPPMPath', maxCount: 1 },
  { name: 'reddSafeguards', maxCount: 1 }
]);

app.post('/project/create/:entityId', requireRole('REQUESTER','ADMIN'), projectUploads, async (req, res) => {
  const entity = await prisma.entity.findUnique({ where: { id: req.params.entityId } });
  if (!entity || (entity.ownerId !== req.session.user.id && req.session.user.role !== 'ADMIN')) return res.status(404).send('Entidad no encontrada');
  if (entity.status !== 'APPROVED') return res.status(403).send('La entidad debe estar aprobada');

  const required = ['holderName','idNumber','contactData','projectName','mitigationType','sector'];
  const missing = requiredFields(required, req.body);
  if (missing.length) return res.render('project/create', { entity, error: `Faltan campos: ${missing.join(', ')}` });

  const p = await prisma.project.create({
    data: {
      holderName: req.body.holderName,
      representative: req.body.representative || null,
      idNumber: req.body.idNumber,
      registryNumber: req.body.registryNumber || null,
      contactData: req.body.contactData,
      projectName: req.body.projectName,
      mitigationType: req.body.mitigationType,
      sector: req.body.sector,
      voluntaryId: req.body.voluntaryId || null,
      licEnvPath: req.files['licEnvPath']?.[0]?.path || null,
      ddmmPath: req.files['ddmmPath']?.[0]?.path || null,
      ovvValidation: req.files['ovvValidation']?.[0]?.path || null,
      minutesPath: req.files['minutesPath']?.[0]?.path || null,
      reddGeojsonPath: req.files['reddGeojsonPath']?.[0]?.path || null,
      reddPPMPath: req.files['reddPPMPath']?.[0]?.path || null,
      reddSafeguards: req.files['reddSafeguards']?.[0]?.path || null,
      ownerId: req.session.user.id,
      entityId: entity.id
    }
  });

  await notifyReviewers(`Nueva medida/proyecto: ${p.projectName}`);
  res.redirect('/dashboard');
});

app.post('/review/project/:id/derive', requireRole('REVIEWER','ADMIN'), async (req, res) => {
  const { institution, notes } = req.body;
  const project = await prisma.project.update({ where: { id: req.params.id }, data: { sentToInstitution: institution, reviewerNotes: notes } });
  await notifySectorHeads(`Solicitud de criterio técnico para: ${project.projectName} → ${institution}`);
  res.redirect('/review/inbox');
});

app.get('/sector/inbox', requireRole('SECTOR_HEAD','ADMIN'), async (req, res) => {
  const projects = await prisma.project.findMany({ where: { sentToInstitution: { not: null } } , include: { entity: true, owner: true }});
  res.render('sector/inbox', { projects });
});

app.get('/sector/project/:id', requireRole('SECTOR_HEAD','ADMIN'), async (req, res) => {
  const project = await prisma.project.findUnique({ where: { id: req.params.id }, include: { entity: true, owner: true } });
  res.render('sector/project-detail', { project });
});

app.post('/sector/project/:id/opinion', requireRole('SECTOR_HEAD','ADMIN'), async (req, res) => {
  const { opinion, notes } = req.body;
  const status = opinion === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  const project = await prisma.project.update({ where: { id: req.params.id }, data: { status, sectorOpinion: opinion, sectorReviewerNotes: notes } , include: { owner: true, entity: true }});
  await notifyReviewers(`Criterio técnico recibido para ${project.projectName}: ${status}`);
  await sendMail({ to: project.owner.email, subject: 'RENAPP: resultado de evaluación sectorial', html: `<p>Proyecto: <b>${project.projectName}</b></p><p>Estado: <b>${status}</b></p><p>${notes || ''}</p>` });
  res.redirect('/sector/inbox');
});

async function notifyReviewers(message) {
  const reviewers = await prisma.user.findMany({ where: { role: { in: ['REVIEWER','ADMIN'] } } });
  for (const r of reviewers) {
    await sendMail({ to: r.email, subject: 'RENAPP: nueva solicitud', html: `<p>${message}</p>` });
  }
}
async function notifySectorHeads(message) {
  const heads = await prisma.user.findMany({ where: { role: { in: ['SECTOR_HEAD','ADMIN'] } } });
  for (const h of heads) {
    await sendMail({ to: h.email, subject: 'RENAPP: solicitud de criterio técnico', html: `<p>${message}</p>` });
  }
}

app.get('/init-demo-users', async (_req, res) => {
  const demoUsers = [
    { username: 'admin', role: 'ADMIN', email: 'admin@example.com' },
    { username: 'revisor', role: 'REVIEWER', email: 'revisor@example.com' },
    { username: 'sector', role: 'SECTOR_HEAD', email: 'sector@example.com' }
  ];
  for (const u of demoUsers) {
    const exists = await prisma.user.findUnique({ where: { username: u.username } });
    if (!exists) {
      await prisma.user.create({ data: {
        username: u.username,
        passwordHash: '$2b$10$E4m8x2bXGxI1X2nQwVg7EupH4mZCq9vU5q3xA2tXj2aS7xK8lV0kK', // hash de "admin123"
        role: u.role,
        status: 'APPROVED',
        fullName: u.username.toUpperCase(),
        ciNumber: '0', jobTitleEntity: '—', address: '—', email: u.email, departmentCity: '—'
      }});
    }
  }
  res.send('Usuarios demo listos: admin/admin123, revisor/admin123, sector/admin123');
});

// Archivo público (ver docs subidos)
app.get('/public-file', (req, res) => {
  const p = req.query.path;
  if (!p) return res.status(400).send('Sin ruta');
  res.sendFile(path.resolve(p));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`RENAPP registro escuchando en http://localhost:${PORT}`));
