import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export async function createUserWithStep1(data) {
  const { fullName, ciNumber, jobTitleEntity, address, email, departmentCity, docRepresentationPath, docREJAPPath } = data;
  const tmpUsername = `tmp_${Date.now()}_${Math.floor(Math.random()*1000)}`;
  const tmpPasswordHash = await bcrypt.hash(`tmp-${Math.random().toString(36).slice(2)}`, 10);

  return prisma.user.create({
    data: {
      username: tmpUsername,
      passwordHash: tmpPasswordHash,
      role: 'REQUESTER',
      status: 'PENDING',
      fullName, ciNumber, jobTitleEntity, address, email, departmentCity,
      docRepresentationPath, docREJAPPath
    }
  });
}

export async function finalizeUserCredentials(userId, username, password) {
  const exists = await prisma.user.findUnique({ where: { username } });
  if (exists && exists.id !== userId) throw new Error('El nombre de usuario ya está en uso.');
  const passwordHash = await bcrypt.hash(password, 10);
  return prisma.user.update({ where: { id: userId }, data: { username, passwordHash } });
}

export async function authenticate(username, password) {
  const user = await prisma.user.findUnique({ where: { username } });
  if (!user) return null;
  const ok = await bcrypt.compare(password, user.passwordHash);
  return ok ? user : null;
}
