# RENAPP – Plataforma de Registro (MVP)

MVP full‑stack con Node/Express, Prisma (SQLite), EJS, Tailwind (CDN), Multer para cargas y Nodemailer para correos.

## Puesta en marcha

1) Instalar dependencias
```bash
npm install
```

2) Variables
```bash
copy .env.example .env   # Windows
cp .env.example .env     # macOS/Linux
```

3) Migraciones
```bash
npx prisma migrate dev --name init
```

4) Levantar el servidor
```bash
npm run dev
```

Visita `http://localhost:3000` y usa `/init-demo-users` para crear cuentas de prueba.
